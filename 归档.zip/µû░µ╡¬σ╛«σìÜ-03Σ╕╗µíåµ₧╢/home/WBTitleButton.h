//
//  WBTitleButton.h
//  新浪微博-03主框架
//
//  Created by DuChunhui on 15/5/11.
//  Copyright (c) 2015年 com.bjsxt. All rights reserved.
//

#import <UIKit/UIKit.h>

@interface WBTitleButton : UIButton
@property(strong,nonatomic)NSString* TitleString;
@end
