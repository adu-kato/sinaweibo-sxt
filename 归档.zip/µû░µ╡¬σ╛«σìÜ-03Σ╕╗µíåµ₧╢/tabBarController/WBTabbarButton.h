//
//  WBTabbarButton.h
//  新浪微博-03主框架
//
//  Created by len on 15-5-8.
//  Copyright (c) 2015年 com.bjsxt. All rights reserved.
//

#import <UIKit/UIKit.h>
//自定义button
@interface WBTabbarButton : UIButton
@property(nonatomic,strong)UITabBarItem* item;//

@end
